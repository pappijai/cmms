<template>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-default">
                    <div class="card-header bgc-teal">
                        <h3 class="card-title text-white"><i class="fas fa-download"></i> Backup Database</h3>
                        <div class="card-tools">
                            <!-- call a function on click to the button -->
                            <a @click="create_backup()" class="btn btn-light text-teal">Add New Backup<span class="fas fa-download fa-fw"></span></a>
                        </div>
                    </div>

                    <div class="card-body table-responsive">
                        <table id="backup_table" class="display table table-stripped table-hover">
                            <thead>
                                <tr>
                                    <th>File</th>
                                    <th>Size</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="backup in backups" :key="backup.id">
                                    <td>{{backup.file_name}}</td>
                                    <td>{{backup.file_size/100000}}kb</td>
                                    <td>
                                        <a class="btn btn-xs btn-success text-white" @click="download_backup(backup)">
                                            <i class="fas fa-download"></i>
                                        </a>
                                        <a class="btn btn-xs btn-danger text-white">
                                            <i class="fas fa-trash"></i>
                                        </a>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>                
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data(){
            return {
                backups: {},
                form: new Form({
                    file_name: '',
                    disk: '',
                })
            }
        },
        methods:{
            loadbackups(){
                axios.get('api/get_backups').then(({ data }) => (this.backups = data));
            },
            create_backup(){
                axios.get('api/create_backup');
            },
            download_backup(backup){
                this.form.fill(backup);
                this.form.put('api/download_backup')
                .then(() => {
                    toast({
                        type: 'success',
                        title: 'Subject Meetings Updated successfully'
                    })     
                    this
                    this.$Progress.finish()
                })
                .catch(() => {
                    this.$Progress.fail()
                })                
            }

        },
        created(){            
        },
        mounted() {    
            this.dt = $('#backup_table').DataTable();
            this.loadbackups();
        },
        watch: {
            // detect all the changes in the table
            backups(val) {
                this.dt.destroy();
                this.$nextTick(() => {
                this.dt = $('#backup_table').DataTable()
                });
            }
        },
    }
</script>
