
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `buildings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildings` (
  `BldgID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BldgName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `BldgCoordinates` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`BldgID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `buildings` WRITE;
/*!40000 ALTER TABLE `buildings` DISABLE KEYS */;
INSERT INTO `buildings` VALUES (1,'Building A','576,319,785,463','2019-01-24 04:09:37','2019-02-24 14:12:08'),(2,'Building B','449,53,652,102','2019-01-24 04:26:10','2019-02-24 14:12:31'),(4,'Building C','730,116,783,304','2019-01-24 05:53:50','2019-02-24 14:00:51'),(5,'Gymnasium','178,123,379,219','2019-02-11 13:52:57','2019-02-24 14:01:16');
/*!40000 ALTER TABLE `buildings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `classroom_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classroom_types` (
  `CTID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CTName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CTID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `classroom_types` WRITE;
/*!40000 ALTER TABLE `classroom_types` DISABLE KEYS */;
INSERT INTO `classroom_types` VALUES (2,'Standard Classroom','2019-01-24 23:28:44','2019-01-25 00:12:17'),(3,'Gymnasium','2019-01-24 23:28:53','2019-01-24 23:28:53'),(4,'Keyboarding Lab','2019-01-24 23:35:14','2019-01-24 23:35:14'),(5,'Computer Lab','2019-01-24 23:38:52','2019-01-24 23:38:52'),(7,'Multimedia','2019-02-05 03:50:07','2019-02-05 03:50:07'),(8,'Mechanical Lab','2019-02-05 03:50:19','2019-02-05 03:50:19'),(9,'ECE Lab','2019-02-05 03:50:35','2019-02-05 03:50:35');
/*!40000 ALTER TABLE `classroom_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `classrooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classrooms` (
  `ClassroomID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ClassroomCode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ClassroomName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ClassroomType` int(11) NOT NULL,
  `ClassroomIn` time NOT NULL,
  `ClassroomOut` time NOT NULL,
  `ClassroomBldg` int(11) NOT NULL,
  `ClassroomFloor` int(11) NOT NULL,
  `ClassroomCoordinates` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ClassroomID`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `classrooms` WRITE;
/*!40000 ALTER TABLE `classrooms` DISABLE KEYS */;
INSERT INTO `classrooms` VALUES (2,'A202','A202',2,'08:00:00','20:30:00',1,10,'183,31,332,161','2019-01-28 03:57:24','2019-02-25 04:48:42'),(3,'A203','A203',2,'08:00:00','20:30:00',1,10,'339,32,488,158','2019-01-29 11:26:02','2019-02-25 04:49:04'),(4,'A204','A204',2,'08:00:00','20:30:00',1,10,'500,32,649,159','2019-01-29 11:26:37','2019-02-25 04:49:28'),(5,'A205','Aboitiz Lab',5,'08:00:00','20:30:00',1,10,'661,30,812,161','2019-01-29 11:27:05','2019-02-25 04:49:53'),(7,'A301','A301',2,'08:00:00','20:30:00',1,11,'11,34,162,166','2019-01-29 11:40:06','2019-02-25 04:50:58'),(8,'A302','A302',2,'08:00:00','20:30:00',1,11,'174,33,322,167','2019-01-29 11:47:10','2019-02-25 04:51:28'),(9,'A102','A102',7,'07:30:00','20:00:00',1,1,'261,29,469,157','2019-02-16 12:16:19','2019-02-25 04:47:12'),(10,'A208','D.O.S.T',5,'07:30:00','20:00:00',1,10,'472,442,789,570','2019-02-16 12:26:55','2019-02-25 05:12:00'),(11,'A303','A303',2,'07:30:00','20:00:00',1,11,'332,35,482,164','2019-02-16 12:29:59','2019-02-25 04:52:26'),(12,'A304','A304',2,'07:30:00','20:00:00',1,11,'495,35,647,164','2019-02-16 12:32:37','2019-02-25 04:52:55'),(13,'A305','A305',2,'07:30:00','20:00:00',1,11,'660,35,809,165','2019-02-16 12:33:52','2019-02-25 04:53:24'),(14,'A307','A307',2,'07:30:00','20:00:00',1,11,'179,440,330,570','2019-02-16 12:34:09','2019-02-25 04:54:11'),(15,'A308','A308',2,'07:30:00','20:00:00',1,11,'343,439,492,571','2019-02-16 12:34:35','2019-02-25 04:54:41'),(16,'A309','A309',2,'07:30:00','20:00:00',1,11,'502,441,653,568','2019-02-16 12:35:02','2019-02-25 04:55:16'),(17,'A310','A310',2,'07:30:00','20:00:00',1,11,'664,439,817,569','2019-02-16 12:35:27','2019-02-25 04:55:45'),(18,'A401','A401',2,'07:30:00','20:00:00',1,12,'11,34,163,166','2019-02-16 13:10:10','2019-02-25 04:56:30'),(19,'A402','A402',2,'07:30:00','20:00:00',1,12,'174,35,324,164','2019-02-16 13:10:36','2019-02-25 04:57:01'),(20,'A403','A403',2,'07:30:00','20:00:00',1,12,'335,35,488,167','2019-02-16 13:10:55','2019-02-25 04:57:33'),(21,'A404','A404',2,'07:30:00','20:00:00',1,12,'497,33,648,165','2019-02-16 13:11:14','2019-02-25 04:58:09'),(22,'A405','A405',2,'07:30:00','20:00:00',1,12,'658,34,809,166','2019-02-16 13:11:34','2019-02-25 04:58:38'),(23,'A410','Keyboarding Laboratory',4,'07:30:00','20:00:00',1,12,'420,440,814,570','2019-02-16 13:12:08','2019-02-25 04:59:12'),(24,'Gymnasium','Gymnasium',3,'07:30:00','21:00:00',5,15,'167,59,757,309','2019-02-18 03:27:15','2019-02-25 05:03:22'),(25,'B101','B101',2,'07:30:00','21:00:00',2,9,'145,64,255,199','2019-02-25 03:50:31','2019-02-25 04:59:50'),(26,'B102','B102',2,'07:30:00','21:00:00',2,9,'262,64,375,200','2019-02-25 03:50:49','2019-02-25 05:00:20'),(27,'B103','B103',2,'07:30:00','21:00:00',2,9,'380,65,492,199','2019-02-25 03:51:11','2019-02-25 05:00:49'),(28,'B104','ECE Lab',9,'07:30:00','21:00:00',2,9,'497,65,608,199','2019-02-25 03:51:36','2019-02-25 05:01:15'),(29,'C101','Mechanical Laboratory',8,'07:30:00','21:00:00',4,14,'205,57,559,282','2019-02-25 03:52:20','2019-02-25 05:02:16'),(30,'C102','C102',2,'07:30:00','21:00:00',4,14,'568,56,795,280','2019-02-25 03:53:28','2019-02-25 05:02:52');
/*!40000 ALTER TABLE `classrooms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `course_subject_offereds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_subject_offereds` (
  `CSOID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SubjectID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `CSOYear` int(11) NOT NULL,
  `CSOSem` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CSOID`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `course_subject_offereds` WRITE;
/*!40000 ALTER TABLE `course_subject_offereds` DISABLE KEYS */;
INSERT INTO `course_subject_offereds` VALUES (42,20,1,1,'First Semester','2019-02-11 14:08:46','2019-02-11 14:08:46'),(43,41,1,1,'Second Semester','2019-02-11 14:08:52','2019-02-11 14:08:52'),(44,21,1,1,'First Semester','2019-02-11 14:08:55','2019-02-11 14:08:55'),(45,42,1,1,'Second Semester','2019-02-11 14:08:57','2019-02-11 14:08:57'),(46,26,1,1,'First Semester','2019-02-11 14:09:00','2019-02-11 14:09:00'),(47,43,1,1,'Second Semester','2019-02-11 14:09:39','2019-02-11 14:09:39'),(48,15,1,1,'First Semester','2019-02-11 14:09:43','2019-02-11 14:09:43'),(49,19,1,1,'Second Semester','2019-02-11 14:09:46','2019-02-11 14:09:46'),(50,17,1,1,'First Semester','2019-02-11 14:09:50','2019-02-11 14:09:50'),(51,18,1,1,'Second Semester','2019-02-11 14:09:52','2019-02-11 14:09:52'),(52,23,1,1,'First Semester','2019-02-11 14:09:58','2019-02-11 14:09:58'),(53,49,1,1,'Second Semester','2019-02-11 14:10:02','2019-02-11 14:10:02'),(54,24,1,1,'First Semester','2019-02-11 14:10:09','2019-02-11 14:10:09'),(55,29,1,1,'Second Semester','2019-02-11 14:10:13','2019-02-11 14:10:13'),(56,40,1,2,'First Semester','2019-02-11 14:10:26','2019-02-11 14:10:26'),(57,45,1,2,'Second Semester','2019-02-11 14:10:27','2019-02-11 14:10:27'),(58,27,1,2,'First Semester','2019-02-11 14:10:35','2019-02-11 14:10:35'),(59,25,1,2,'Second Semester','2019-02-11 14:10:39','2019-02-11 14:10:39'),(60,30,1,2,'First Semester','2019-02-11 14:10:44','2019-02-11 14:10:44'),(61,28,1,1,'First Semester','2019-02-11 14:11:00','2019-02-11 14:11:00'),(62,31,1,2,'First Semester','2019-02-22 12:35:20','2019-02-22 12:35:20'),(63,44,1,2,'Second Semester','2019-02-22 12:35:25','2019-02-22 12:35:25'),(64,48,1,2,'Second Semester','2019-02-22 12:35:27','2019-02-22 12:35:27'),(65,30,1,2,'Second Semester','2019-02-22 12:35:30','2019-02-22 12:35:30'),(66,20,1,3,'First Semester','2019-02-22 12:35:35','2019-02-22 12:35:35'),(67,21,1,3,'First Semester','2019-02-22 12:35:37','2019-02-22 12:35:37'),(68,44,1,3,'First Semester','2019-02-22 12:35:40','2019-02-22 12:35:40'),(69,47,1,3,'First Semester','2019-02-22 12:35:43','2019-02-22 12:35:43'),(70,43,1,3,'Second Semester','2019-02-22 12:35:46','2019-02-22 12:35:46'),(71,22,1,3,'Second Semester','2019-02-22 12:35:49','2019-02-22 12:35:49'),(72,18,1,3,'Second Semester','2019-02-22 12:35:52','2019-02-22 12:35:52'),(73,26,1,3,'Second Semester','2019-02-22 12:36:08','2019-02-22 12:36:08'),(74,48,1,3,'Second Semester','2019-02-22 12:36:19','2019-02-22 12:36:19'),(75,26,1,4,'First Semester','2019-02-22 12:37:31','2019-02-22 12:37:31'),(76,19,1,4,'First Semester','2019-02-22 12:37:33','2019-02-22 12:37:33'),(77,23,1,4,'First Semester','2019-02-22 12:37:36','2019-02-22 12:37:36'),(78,27,1,4,'First Semester','2019-02-22 12:37:40','2019-02-22 12:37:40'),(79,22,1,4,'Second Semester','2019-02-22 12:37:43','2019-02-22 12:37:43'),(80,26,1,4,'Second Semester','2019-02-22 12:37:45','2019-02-22 12:37:45'),(81,18,1,4,'Second Semester','2019-02-22 12:37:48','2019-02-22 12:37:48'),(82,23,1,4,'Second Semester','2019-02-22 12:37:50','2019-02-22 12:37:50'),(83,41,2,1,'First Semester','2019-02-27 03:32:11','2019-02-27 03:32:11'),(84,42,2,1,'Second Semester','2019-02-27 03:32:20','2019-02-27 03:32:20');
/*!40000 ALTER TABLE `course_subject_offereds` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `CourseID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CourseCode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CourseDescription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CourseYears` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CourseID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'BSIT','Bachelor of Science in Information Technology',4,'2019-02-05 04:49:23','2019-02-05 04:49:23'),(2,'BSA','Bachelor of Science in Accountancy',4,'2019-02-05 04:56:36','2019-02-07 01:57:01'),(5,'BSAM','Bachelor of Science in Applied Mathematics',4,'2019-02-06 16:10:49','2019-02-06 16:10:49'),(6,'BSOA','Bachelor of Science in Office Management',4,'2019-02-07 02:06:17','2019-02-07 02:06:17');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `days` (
  `DayID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DayName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`DayID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `days` WRITE;
/*!40000 ALTER TABLE `days` DISABLE KEYS */;
INSERT INTO `days` VALUES (1,'Monday',NULL,NULL),(2,'Tuesday',NULL,NULL),(3,'Wednesday',NULL,NULL),(4,'Thursday',NULL,NULL),(5,'Friday',NULL,NULL),(6,'Saturday',NULL,NULL);
/*!40000 ALTER TABLE `days` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `floorplans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `floorplans` (
  `FloorplanID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `FloorplanName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FloorplanPhoto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`FloorplanID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `floorplans` WRITE;
/*!40000 ALTER TABLE `floorplans` DISABLE KEYS */;
INSERT INTO `floorplans` VALUES (1,'PUP Taguig','1551017479.png',NULL,NULL);
/*!40000 ALTER TABLE `floorplans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `floors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `floors` (
  `BFID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BldgID` int(11) NOT NULL,
  `BFName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `BFPhoto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`BFID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `floors` WRITE;
/*!40000 ALTER TABLE `floors` DISABLE KEYS */;
INSERT INTO `floors` VALUES (1,1,'1st Floor','1551068186.png','2019-01-24 07:59:27','2019-02-25 04:16:27'),(9,2,'1st Floor','1551068215.png','2019-01-24 08:33:33','2019-02-25 04:16:55'),(10,1,'2nd Floor','1551068194.png','2019-01-24 08:42:39','2019-02-25 04:16:34'),(11,1,'3rd Floor','1551068201.png','2019-01-29 11:24:45','2019-02-25 04:16:41'),(12,1,'4th Floor','1551068207.png','2019-01-29 11:24:57','2019-02-25 04:16:47'),(14,4,'1st Floor','1551068220.png','2019-01-29 11:25:15','2019-02-25 04:17:00'),(15,5,'1st Floor','1551068226.png','2019-02-11 13:53:13','2019-02-25 04:17:07');
/*!40000 ALTER TABLE `floors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_06_01_000001_create_oauth_auth_codes_table',1),(4,'2016_06_01_000002_create_oauth_access_tokens_table',1),(5,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(6,'2016_06_01_000004_create_oauth_clients_table',1),(7,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(8,'2019_01_24_033210_create_buildings_table',2),(9,'2019_01_24_062049_create_floors_table',3),(10,'2019_01_24_131724_create_rooms_table',4),(11,'2019_01_24_133030_create_classrooms_table',4),(12,'2019_01_24_133240_create_classroom_types_table',4),(13,'2019_01_29_115843_create_subjects_table',5),(14,'2019_01_31_110638_create_subject_meetings_table',6),(15,'2019_02_05_042938_create_courses_table',7),(16,'2019_02_06_112128_create_course_subject_offereds_table',8),(17,'2019_02_07_022110_create_professors_table',9),(18,'2019_02_11_081855_create_sections_table',10),(19,'2019_02_17_034836_create_subject_taggings_table',11),(20,'2019_02_17_124020_create_subject_tagging_schedules_table',12),(21,'2019_02_17_143834_create_schedules_table',13),(22,'2019_02_17_145935_create_days_table',14),(23,'2019_02_23_035247_create_floorplans_table',15);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `professors` (
  `ProfessorID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ProfessorName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ProfessorID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `professors` WRITE;
/*!40000 ALTER TABLE `professors` DISABLE KEYS */;
INSERT INTO `professors` VALUES (1,'Prof. Elvin Catantan','2019-02-07 02:31:04','2019-02-07 02:50:50'),(2,'Prof. Ron Alayon','2019-02-07 02:34:10','2019-02-07 02:34:10'),(3,'Prof. Larry Aumentado','2019-02-17 03:35:51','2019-02-17 03:35:51'),(4,'Prof. Bernadette Canlas','2019-02-17 03:36:02','2019-02-17 03:36:02'),(5,'Prof. Gina Dela Cruz','2019-02-17 03:36:29','2019-02-17 03:36:29'),(6,'Prof. Raegan Ricafort','2019-02-17 03:36:42','2019-02-17 03:36:42'),(7,'Prof. Marian Arada','2019-02-17 03:37:28','2019-02-17 03:37:28'),(8,'Prof. Mayghie Galarce','2019-02-17 03:37:51','2019-02-17 03:37:51'),(9,'Prof. Florante Andres','2019-02-17 03:38:28','2019-02-17 03:38:28'),(10,'Prof. Marilou Novida','2019-02-17 03:38:38','2019-02-17 03:38:38'),(11,'Prof. Asuncion Gabasa','2019-02-17 03:38:48','2019-02-17 03:38:48'),(12,'Prof. Alyssa Teodoro','2019-02-17 03:39:05','2019-02-17 03:39:05'),(13,'Prof. Rosita Canlas','2019-02-17 03:39:14','2019-02-17 03:39:14'),(14,'Prof. Bryan Llenarizas','2019-02-17 03:39:26','2019-02-17 03:39:26'),(15,'Prof. Elias Austria','2019-02-17 03:39:45','2019-02-17 03:39:45'),(16,'Prof. Flordeliz Garcia','2019-02-17 03:39:55','2019-02-17 03:39:55'),(17,'Prof. Marvin Arriola','2019-02-17 03:40:07','2019-02-17 03:40:07'),(18,'Prof. Jose Malate','2019-02-17 03:40:18','2019-02-17 03:40:18'),(19,'Prof. Marifel Javier','2019-02-17 03:40:26','2019-02-17 03:40:26');
/*!40000 ALTER TABLE `professors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `SchedID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SchedTime` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`SchedID`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,'07:30:00',NULL,NULL),(2,'08:00:00',NULL,NULL),(3,'08:30:00',NULL,NULL),(4,'09:00:00',NULL,NULL),(5,'09:30:00',NULL,NULL),(6,'10:00:00',NULL,NULL),(7,'10:30:00',NULL,NULL),(8,'11:00:00',NULL,NULL),(9,'11:30:00',NULL,NULL),(10,'12:00:00',NULL,NULL),(11,'12:30:00',NULL,NULL),(12,'13:00:00',NULL,NULL),(13,'13:30:00',NULL,NULL),(14,'14:00:00',NULL,NULL),(15,'14:30:00',NULL,NULL),(16,'15:00:00',NULL,NULL),(17,'15:30:00',NULL,NULL),(18,'16:00:00',NULL,NULL),(19,'16:30:00',NULL,NULL),(20,'17:00:00',NULL,NULL),(21,'17:30:00',NULL,NULL),(22,'18:00:00',NULL,NULL),(23,'18:30:00',NULL,NULL),(24,'19:30:00',NULL,NULL),(25,'20:00:00',NULL,NULL),(26,'20:30:00',NULL,NULL),(27,'21:00:00',NULL,NULL),(28,'19:00:00',NULL,NULL);
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `SectionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CourseID` int(11) NOT NULL,
  `SectionYear` year(4) NOT NULL,
  `SectionName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SectionStatus` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`SectionID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,1,2015,'1','Active','2019-02-11 09:16:14','2019-02-25 11:50:26'),(2,1,2018,'2','Active','2019-02-11 09:22:34','2019-02-17 06:37:18'),(3,1,2016,'3','Active','2019-02-17 03:44:40','2019-02-17 06:12:12'),(4,2,2018,'1','Active','2019-02-25 11:31:03','2019-02-25 11:33:51'),(5,5,2018,'1','Active','2019-02-25 11:47:11','2019-02-25 11:51:29');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subject_meetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_meetings` (
  `SMID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SubjectID` int(11) NOT NULL,
  `CTID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SubjectHours` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`SMID`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subject_meetings` WRITE;
/*!40000 ALTER TABLE `subject_meetings` DISABLE KEYS */;
INSERT INTO `subject_meetings` VALUES (10,15,'2',2,'2019-01-31 12:20:20','2019-02-05 03:47:42'),(11,15,'5',2,'2019-01-31 12:20:20','2019-02-05 03:47:48'),(12,16,'2',2,'2019-01-31 12:20:40','2019-02-05 03:48:15'),(13,16,'5',2,'2019-01-31 12:20:40','2019-02-05 03:48:13'),(14,17,'2',2,'2019-01-31 12:21:51','2019-02-05 03:48:25'),(15,18,'2',2,'2019-02-05 03:21:30','2019-02-05 03:48:38'),(17,19,'5',2,'2019-02-05 14:10:40','2019-02-06 03:56:59'),(18,20,'2',2,'2019-02-06 03:11:58','2019-02-11 13:58:41'),(19,21,'2',3,'2019-02-06 03:16:27','2019-02-06 03:16:43'),(20,22,'2',2,'2019-02-06 03:17:24','2019-02-06 03:18:30'),(21,23,'4',2,'2019-02-06 03:18:53','2019-02-06 03:19:28'),(22,24,'3',2,'2019-02-06 03:20:52','2019-02-06 03:21:09'),(23,25,'2',2,'2019-02-06 03:24:34','2019-02-06 03:24:52'),(24,26,'2',2,'2019-02-06 03:26:13','2019-02-06 03:27:32'),(25,27,'2',2,'2019-02-06 03:28:02','2019-02-06 03:28:57'),(26,28,'2',2,'2019-02-06 03:30:29','2019-02-06 03:30:50'),(27,29,'3',2,'2019-02-06 03:33:32','2019-02-06 03:35:18'),(28,30,'5',2,'2019-02-06 03:35:45','2019-02-06 03:36:08'),(29,31,'2',3,'2019-02-06 03:37:20','2019-02-06 03:37:54'),(40,40,'3',2,'2019-02-06 03:56:01','2019-02-06 03:56:29'),(41,19,'2',2,'2019-02-06 03:57:18','2019-02-06 03:57:28'),(42,41,'2',2,'2019-02-11 13:58:57','2019-02-11 13:59:01'),(43,42,'2',3,'2019-02-11 13:59:33','2019-02-11 13:59:40'),(44,43,'2',3,'2019-02-11 14:00:27','2019-02-11 14:00:30'),(45,44,'2',2,'2019-02-11 14:01:04','2019-02-11 14:01:07'),(46,45,'3',2,'2019-02-11 14:01:44','2019-02-11 14:01:49'),(47,46,'2',2,'2019-02-11 14:03:36','2019-02-11 14:03:48'),(48,46,'5',2,'2019-02-11 14:03:36','2019-02-11 14:03:50'),(49,47,'2',2,'2019-02-11 14:04:12','2019-02-11 14:04:20'),(50,47,'5',2,'2019-02-11 14:04:12','2019-02-11 14:04:19'),(51,48,'2',2,'2019-02-11 14:04:43','2019-02-11 14:04:50'),(52,48,'5',2,'2019-02-11 14:04:43','2019-02-11 14:04:49'),(53,49,'4',2,'2019-02-11 14:05:17','2019-02-11 14:05:24');
/*!40000 ALTER TABLE `subject_meetings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subject_tagging_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_tagging_schedules` (
  `STSID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `STID` int(11) NOT NULL,
  `SMID` int(11) NOT NULL,
  `ClassroomID` int(11) NOT NULL,
  `STSTimeStart` time NOT NULL,
  `STSTimeEnd` time NOT NULL,
  `STSDay` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STSStatus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`STSID`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subject_tagging_schedules` WRITE;
/*!40000 ALTER TABLE `subject_tagging_schedules` DISABLE KEYS */;
INSERT INTO `subject_tagging_schedules` VALUES (61,37,42,18,'07:30:00','09:30:00','Wednesday','Active','2019-02-22 11:46:57','2019-02-22 11:46:57'),(62,38,43,13,'09:30:00','12:30:00','Wednesday','Active','2019-02-22 11:47:02','2019-02-22 11:47:02'),(63,39,44,2,'07:30:00','10:30:00','Monday','Active','2019-02-22 11:47:11','2019-02-22 11:47:11'),(64,40,17,10,'07:30:00','09:30:00','Tuesday','Active','2019-02-22 11:47:18','2019-02-22 11:47:18'),(65,40,41,15,'10:30:00','12:30:00','Monday','Active','2019-02-22 11:47:18','2019-02-22 11:47:18'),(66,41,15,7,'09:30:00','11:30:00','Tuesday','Active','2019-02-22 11:47:36','2019-02-22 11:47:36'),(67,42,53,23,'07:30:00','09:30:00','Thursday','Active','2019-02-22 11:47:55','2019-02-22 11:47:55'),(68,43,27,24,'09:30:00','11:30:00','Thursday','Active','2019-02-22 11:49:01','2019-02-22 11:49:01'),(69,44,44,12,'07:30:00','10:30:00','Monday','Active','2019-02-22 12:38:08','2019-02-22 12:38:08'),(70,45,20,15,'07:30:00','09:30:00','Thursday','Active','2019-02-22 12:38:20','2019-02-22 12:38:20'),(71,46,51,16,'07:30:00','09:30:00','Wednesday','Active','2019-02-22 12:38:27','2019-02-22 12:38:27'),(72,46,52,5,'07:30:00','09:30:00','Saturday','Active','2019-02-22 12:38:27','2019-02-22 12:38:27'),(73,47,24,12,'09:30:00','11:30:00','Saturday','Active','2019-02-22 12:38:36','2019-02-22 12:38:36'),(74,48,20,4,'07:30:00','09:30:00','Tuesday','Active','2019-02-22 12:38:58','2019-02-22 12:38:58'),(75,49,24,4,'07:30:00','09:30:00','Saturday','Active','2019-02-22 12:39:01','2019-02-22 12:39:01'),(76,50,15,2,'09:30:00','11:30:00','Tuesday','Active','2019-02-22 12:39:04','2019-02-22 12:39:04'),(77,51,21,23,'09:30:00','11:30:00','Thursday','Active','2019-02-22 12:39:13','2019-02-22 12:39:13');
/*!40000 ALTER TABLE `subject_tagging_schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subject_taggings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject_taggings` (
  `STID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SubjectID` int(11) NOT NULL,
  `ProfessorID` int(11) NOT NULL,
  `SectionID` int(11) NOT NULL,
  `STSem` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `STYear` int(11) NOT NULL,
  `STYearFrom` year(4) NOT NULL,
  `STYearTo` year(4) NOT NULL,
  `STStatus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`STID`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subject_taggings` WRITE;
/*!40000 ALTER TABLE `subject_taggings` DISABLE KEYS */;
INSERT INTO `subject_taggings` VALUES (37,41,12,2,'Second Semester',1,2018,2019,'Active','2019-02-22 11:46:57','2019-02-22 11:46:57'),(38,42,15,2,'Second Semester',1,2018,2019,'Active','2019-02-22 11:47:02','2019-02-22 11:47:02'),(39,43,1,2,'Second Semester',1,2018,2019,'Active','2019-02-22 11:47:11','2019-02-22 11:47:11'),(40,19,1,2,'Second Semester',1,2018,2019,'Active','2019-02-22 11:47:18','2019-02-22 11:47:18'),(41,18,17,2,'Second Semester',1,2018,2019,'Active','2019-02-22 11:47:36','2019-02-22 11:47:36'),(42,49,16,2,'Second Semester',1,2018,2019,'Active','2019-02-22 11:47:55','2019-02-22 11:47:55'),(43,29,4,2,'Second Semester',1,2018,2019,'Active','2019-02-22 11:49:01','2019-02-22 11:49:01'),(44,43,14,3,'Second Semester',3,2018,2019,'Active','2019-02-22 12:38:08','2019-02-22 12:38:08'),(45,22,15,3,'Second Semester',3,2018,2019,'Active','2019-02-22 12:38:20','2019-02-22 12:38:20'),(46,48,9,3,'Second Semester',3,2018,2019,'Active','2019-02-22 12:38:27','2019-02-22 12:38:27'),(47,26,1,3,'Second Semester',3,2018,2019,'Active','2019-02-22 12:38:36','2019-02-22 12:38:36'),(48,22,12,1,'Second Semester',4,2018,2019,'Active','2019-02-22 12:38:58','2019-02-22 12:38:58'),(49,26,4,1,'Second Semester',4,2018,2019,'Active','2019-02-22 12:39:01','2019-02-22 12:39:01'),(50,18,4,1,'Second Semester',4,2018,2019,'Active','2019-02-22 12:39:04','2019-02-22 12:39:04'),(51,23,1,1,'Second Semester',4,2018,2019,'Active','2019-02-22 12:39:13','2019-02-22 12:39:13');
/*!40000 ALTER TABLE `subject_taggings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `SubjectID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `SubjectCode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SubjectDescription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SubjectMeetings` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`SubjectID`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (15,'COMPROG 1','Computer Programming 1',2,'2019-01-31 12:20:20','2019-02-03 10:51:25'),(16,'DBMS 1','Database Management 1',2,'2019-01-31 12:20:40','2019-01-31 12:20:40'),(17,'FIL 1','Filipino 1',1,'2019-01-31 12:21:51','2019-01-31 12:21:51'),(18,'FIL 2','Filipino 2',1,'2019-02-05 03:21:30','2019-02-05 03:21:30'),(19,'COMPROG 2','Computer Programming 2',2,'2019-02-05 14:10:40','2019-02-06 03:57:18'),(20,'ACP 1','Accounting Principles',1,'2019-02-06 03:11:58','2019-02-11 13:58:34'),(21,'ICT 114','Basic Computer Hardware Servicing',1,'2019-02-06 03:16:27','2019-02-06 03:16:27'),(22,'ITMT 111','College Algebra',1,'2019-02-06 03:17:24','2019-02-06 03:17:24'),(23,'ICT 115','Keyboarding 1',1,'2019-02-06 03:18:53','2019-02-06 03:18:53'),(24,'PE 111','Physical Education 1',1,'2019-02-06 03:20:52','2019-02-06 03:20:52'),(25,'ITEN 111','Study and Thinking Skills in English',1,'2019-02-06 03:24:34','2019-02-06 03:24:34'),(26,'ICT 124','Basic Electronics',1,'2019-02-06 03:26:13','2019-02-06 03:26:13'),(27,'ITEN 112','Speech Communication',1,'2019-02-06 03:28:01','2019-02-06 03:28:01'),(28,'ICT 125','Professional Ethics',1,'2019-02-06 03:30:29','2019-02-06 03:30:29'),(29,'PE 112','Physical Education 2',1,'2019-02-06 03:33:32','2019-02-06 03:33:32'),(30,'IT 121','Integrated Application Software',1,'2019-02-06 03:35:45','2019-02-06 03:35:45'),(31,'ICT 216','Operating System',2,'2019-02-06 03:37:20','2019-02-06 03:53:28'),(40,'PE 113','Physical Education 3',1,'2019-02-06 03:50:47','2019-02-06 03:56:20'),(41,'ACP 2','Accounting Principles 2',1,'2019-02-11 13:58:57','2019-02-11 13:58:57'),(42,'BHS 111','Basic Computer Hardware Servicing 2',1,'2019-02-11 13:59:33','2019-02-11 13:59:33'),(43,'BE 2','Basic Electronics 2',1,'2019-02-11 14:00:27','2019-02-11 14:00:27'),(44,'CA 2','College Algebra 2',1,'2019-02-11 14:01:04','2019-02-11 14:01:04'),(45,'PE 114','Physical Education 4',1,'2019-02-11 14:01:44','2019-02-11 14:01:44'),(46,'COMPROG 3','Computer Programming 3',2,'2019-02-11 14:03:36','2019-02-11 14:03:36'),(47,'COMPROG 4','Computer Programming 4',2,'2019-02-11 14:04:12','2019-02-11 14:04:12'),(48,'DBMS 2','Database Management 2',2,'2019-02-11 14:04:43','2019-02-11 14:04:43'),(49,'ICT 116','Keyboarding 2',1,'2019-02-11 14:05:17','2019-02-11 14:05:17');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'profile.png',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'John Alfred Intia','johnintia30@gmail.com','$2y$10$girG7V0cDZIOxgL.VOCWd.Jm.ECtzaqMr9..o1GQ7/xN9z58.fxPi','admin','1551099073.jpeg','yNA9hxGWqyXyfqL2AOYuY3SwzQx6cpZJ4cwIaheOR2qaFWEJ7evP4sf1dbTN','2019-01-23 02:28:38','2019-02-25 04:51:14'),(2,'Rizz Faustinoo','rizzfaustino@gmail.com','$2y$10$1Uqt6aMld340R21Eu2T3k.0//LMjNxJhal65QSXfXwqUGG4Fngg1C','user','people.png',NULL,'2019-01-23 10:52:29','2019-01-23 13:37:37'),(7,'test1','test@gmail.com','$2y$10$4vOa8a6h9/.idiRlHwgN1Oma3jolki2tRo3xaN28JwYzEXy8ihbuK','user','people.png',NULL,'2019-01-23 13:45:15','2019-01-23 15:32:50'),(8,'test2','test2@gmail.com','$2y$10$7Q1ex81fvC8iD6Xd1VDtWO/x3.pjhEDbaW028w2cF9mXWJWfSIaGu','user','1551099215.png','3MjuzDcMtYCL0j58T4XEpIFj0ndEy86Ul42xUigwgjtAIC9fFez3kc5cHiJr','2019-02-25 12:43:39','2019-02-25 13:16:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

