<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubjectMeeting extends Model
{
    //
}
